package com.example.project.model;

public enum
CityStatus {
    ACTIVE,
    INACTIVE
}

