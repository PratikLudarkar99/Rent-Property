package com.example.project.enums;

public enum DurationUnit {
    MONTHLY,
    YEARLY
}
