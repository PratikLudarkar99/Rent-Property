package com.example.project.enums;

public enum PropertyCategory {
    RESIDENTIAL, COMMERCIAL, AGRICULTURAL
}
