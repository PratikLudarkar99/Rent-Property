package com.example.project.enums;

public enum PriceDuration {
    DAILY, WEEKLY, MONTHLY, YEARLY
}
