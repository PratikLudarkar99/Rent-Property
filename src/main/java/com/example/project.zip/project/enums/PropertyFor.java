package com.example.project.enums;

public enum PropertyFor {
    RENT, SELL, PG, CO_LIVING
}
