package com.example.project.enums;

public enum Role {
    CUSTOMER,
    BROKER,
    ADMIN
}
