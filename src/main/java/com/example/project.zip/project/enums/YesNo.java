package com.example.project.enums;

public enum YesNo {
    YES, NO
}
