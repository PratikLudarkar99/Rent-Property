package com.example.project.enums;

public enum BhkType {
    BHK_1, BHK_2, BHK_3, BHK_4
}
