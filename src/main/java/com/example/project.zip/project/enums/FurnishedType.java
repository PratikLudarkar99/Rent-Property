package com.example.project.enums;

public enum FurnishedType {
    UNFURNISHED, SEMI, FULLY
}
