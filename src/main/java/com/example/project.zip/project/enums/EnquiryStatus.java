package com.example.project.enums;

public enum EnquiryStatus {
    NEW,
    RESOLVED
}
