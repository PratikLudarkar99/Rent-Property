package com.example.project.enums;

public enum SellerType {
    OWNER, BROKER, BUILDER
}
