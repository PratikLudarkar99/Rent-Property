package com.example.project.enums;

public enum CustomerStatus {
    ACTIVE,
    INACTIVE,
    PENDING

}
