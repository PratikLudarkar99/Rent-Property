package com.example.project.enums;

public enum LimitType {
    LIMIT,
    UNLIMITED

}
